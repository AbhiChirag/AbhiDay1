package com.cdac.account;

import java.util.List;

public class Print {
	public static void printUpper(List<? extends Account> account) {
		System.out.println(account.toString());
	}
	public static void printLower(List<? super Account> account) {
		System.out.println(account.toString());
	}
	public static void print(List<Account> account) {
		System.out.println(account.toString());
	}
}
