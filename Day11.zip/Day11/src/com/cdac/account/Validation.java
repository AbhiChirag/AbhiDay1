package com.cdac.account;

import java.io.IOException;
import java.time.LocalDate;

public class Validation  {
	
	public static double validbalance(double x) throws ArithmeticException   {
		try {
			if(x>1000)
			{
				return x;
			}
			
			throw new ArithmeticException("wrong input");
			
			}
		catch(ArithmeticException e)
			{
				System.out.println(e.getMessage());
				return x;		

			}

	
		
	}
	
	public static LocalDate validdate(String str)
	{
		LocalDate date = LocalDate.parse(str);
		LocalDate now = LocalDate.now();
		if(now.isAfter(date))
		{
			return date;
		}
		return null;
		
	}
	

}
