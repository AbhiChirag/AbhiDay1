package com.cdac.list;

public interface Jk {

	void bark();
	void sound();
	
}
