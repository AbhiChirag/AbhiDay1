package com.cdac.exception;

public class BalanceExcep extends Exception {

	
	public BalanceExcep(String msg) {
		super(msg);
	}
	
}
