package com.cdac.list;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

public class FruitsTester {

	public static void main(String[] args) {
		LinkedList<Fruits> arr = new LinkedList<>();
		Scanner sc = new Scanner(System.in);
		boolean exit = true;
		while(exit) {
			System.out.println("Press 1 for Add Fruits -- Press 2 for Display List of fruits -- Press 3 for Sort fruits by color -- Press 4 for Sort by quantity");
		     System.out.println("Enter the Choice");
		     int choice = sc.nextInt();
		     sc.nextLine();
		     switch(choice) {
		     case 1:
		for(int i=0;i<3;i++)
		{
			System.out.println("Enter the Fruits Name");
			String name = sc.nextLine();
			System.out.println("Enter the Fruits color");
			String color = sc.nextLine();
			System.out.println("Enter the Fruits price");
		     double price = sc.nextDouble();
		     System.out.println("Enter the Fruits quantity");
			int quantity = sc.nextInt();
			sc.nextLine();
			arr.add(new Fruits(name,color,price,quantity));
			
		}
		break;
		
		     case 2:
		    	         arr.forEach(System.out::println);
		    	         break;
		     case 3:
		    	 		
		    	 		Collections.sort(arr);
		    	 		break;
		     case 4:
		    	 NameCo f=new NameCo();
	    	 		Collections.sort(arr,f);
	    	 		break;
		     case 5:
		    	 
		    	 Comparator<Fruits> pricee =new Comparator<Fruits>()
		    	 {

					

					@Override
					public int compare(Fruits o1, Fruits o2) {
						
//						Integer i1=(int) o1.getPrice();
//						Integer i2=(int) o2.getPrice();
						if (o1.getPrice()>o2.getPrice())
						{
				return 1;
						}
						if (o1.getPrice()<o2.getPrice())
						{
				return -1;
						}
						return 0;
					
						
					};
		    		
		    	 };
	    	 	Collections.sort(arr,pricee);

		    	 break;
		    	   
		     case 6:
		    	 exit = false;
		     }
		}
		
		
		     }}
