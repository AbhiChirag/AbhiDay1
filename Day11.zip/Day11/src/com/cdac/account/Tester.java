package com.cdac.account;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import com.cdac.exception.BalanceExcep;

public class Tester {

	public static void main(String [] args) throws BalanceExcep
	
	{	
		//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

		Scanner sc=new Scanner(System.in);
		List<Account> account = new ArrayList<>(); 
		
		
		
		boolean exit=true;
		while(exit)
		{	
			System.out.println("1. Add account\r\n"
				+ "2. Print all accounts\r\n"
				+ "3. Create unmodifiable from existing list\r\n"
				+ "4. Use Upper bound\r\n"
				+ "5. User lower bound\r\n"
				+ "7. exit");
		
		
			int val;
			val=sc.nextInt();
			sc.nextLine();
			switch (val)
			{
			case 1:{
				System.out.println("Enter Name Please");
				String name=sc.nextLine();
				System.out.println("Enter Date in format (dd/MM/yyyy)");
				String date=sc.nextLine();
				System.out.println("Enter balance Please");
				Double balance=sc.nextDouble();
				
				LocalDate date1 = Validation.validdate(date);
				double bal = Validation.validbalance(balance);
				account.add(new Account(name,date,balance));
			}
			break;
				
//				try {
//					
////				if(account.size()>5)
////				{
////				//	throw new Unmodifiable("") 
////				}
//					
//				account.add(new Account(name,date,balance));
//				
//				
//				}
//				catch (BalanceExcep e)
//				{
//					System.out.println(e.getMessage());
//				}
//			}
			
			case 2:
//				
				ListIterator<Account> iterator=account.listIterator();
				while(iterator.hasNext()) {
					Account acc=iterator.next();
					System.out.println(acc.toString());
				}
				break;
				
			case 3:
//				List<Account> d=Collections.unmodifiableList(account);
//				account=d;
			
				
				break;

			
			
				
			case 4:
				     Print p = new Print();
				     p.printUpper(account);
			
	             break;
			case 5:
				 Print u = new Print();
				 u.printLower(account);
				 break;
			case 6:
				exit = false;
			
				
			}
		
		
		}}
	}	
		
		
	

