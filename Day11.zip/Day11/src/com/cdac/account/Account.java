package com.cdac.account;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.cdac.exception.BalanceExcep;
 
public class Account  {

private  int accNo;
private String accName;
private LocalDate dateOfOpening;
double balance;
public static int counter = 2324;
DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");


public Account(String accName, String date , double balance) throws BalanceExcep {
	
	try {
		if(balance<1000)
		{
			throw new BalanceExcep("!! balance less than 1000 !! can't create account");
		}
		this.balance = balance;
	}
	finally
	{
		
	}
	this.accNo = counter++;
	this.accName = accName;
	this.dateOfOpening = LocalDate.parse(date);
		
	
	
}


@Override
public String toString() {

	return "Account [accName=" + accName + ", dateOfOpening=" + dateOfOpening.format(formatter) + ", balance=" + balance + "]";
}



public int getAccNo() {
	return accNo;
}


public void setAccNo(int accNo) {
	this.accNo = accNo;
}


public String getAccName() {
	return accName;
}
public void setAccName(String accName) {
	this.accName = accName;
}
public LocalDate getDateOfOpening() {
	return dateOfOpening;
}
public void setDateOfOpening(LocalDate dateOfOpening) {
	this.dateOfOpening = dateOfOpening;
}

public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}




}
